
#include "graph.h"

// add needed #include directives

using namespace std;

namespace graphs
{

// add implementations of graph class members and friend operators

}