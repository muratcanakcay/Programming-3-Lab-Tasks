﻿using System;

namespace Vehicles
{
    class Vehicle
    {
        
    }
}
