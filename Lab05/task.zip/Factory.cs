﻿
namespace Vehicles
{
    class Factory
    {
        
    }
}
