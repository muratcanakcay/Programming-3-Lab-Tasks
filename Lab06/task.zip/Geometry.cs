﻿using System;

namespace lab06
{
    class Geometry
    {
    }
}
